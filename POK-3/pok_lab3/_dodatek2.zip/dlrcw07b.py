######################################################
# Uzycie parsera IronPython w aplikacji konsolowej   #
# dla srodowiska DLR - skrypt Py modulu zewnetrznego #
# z przykladami programowania dynamicznego w Python2 #
######################################################

# moduly elementow z biblioteki standardowej jezyka IronPython .NET:
import math
import sys

# utworzenie i przetwarzanie zmiennej jako obiektu danych o dynamicznym, niejawnym typie jezyka Python:
print "+++ poczatek skryptu Py +++"
a = 3.14 # typ obiektu danej jest okreslony na podstawie przypisanego wyrazenia
print "Py: ", type(a), " a = ", a
a = 567 # obiekt danej dowiazany do zmiennej w jezyku dynamicznym moze byc zastapiony innym obiektem nawet o odmiennym typie 
print "Py: ", type(a), " a = ", a

# dynamiczny dostep i modyfikacja elementow zdefiniowanych w kodzie jezyka C#:
print "Py: ", type(_zmienna), " _zmienna = ", _zmienna # dostep do typu i wartosci roznych elementow programu jako obiektow danych, instancji klas lub ich pol 
print "Py: ", type(_obiekt), " _obiekt = ", _obiekt
print "Py: ", type(_obiekt.pole), " _obiekt.pole = ", _obiekt.pole
a = _obiekt.metoda(a) # dostep do metody klasy i jej zwrotne wywolanie na rzecz instancji klasy (ang. call-back) z skryptu Py do kodu C#
_zmienna = a # modyfikacja obiektu danej bedacej kopia zmiennej z kodu C# (dowiazanie przez wartosc)
_obiekt.pole = a # modyfikacja pola instancji istniejacej w kodzie C# (dowiazanie przez referencje)
print "Py: ", type(_zmienna), " _zmienna = ", _zmienna
print "Py: ", type(_obiekt), " _obiekt = ", _obiekt
print "Py: ", type(_obiekt.pole), " _obiekt.pole = ", _obiekt.pole

# dynamiczna rozbudowa elementow zdefiniowanych w kodzie jezyka C#:
def wykonaj(x): # wstrzykniecie nowej metody jako lambdy czyli call-back dla kodu Py
    print "metoda Py: ", type(x), " x = ", x
    return 10*x-5
_obiekt.metoda2 = lambda x: wykonaj(x)
_obiekt.pole2 = 2*a # wstrzykniecie nowego pola do dynamicznej instancji klasy
print "Py: ", type(_obiekt.pole2), " _obiekt.pole2 = ", _obiekt.pole2

# wprowadzenie zmiennej do skryptu dostepnej dla kodu C#:
wartosc_ = _zmienna # udostepnienie ostatniej wartosci zmiennej powiazanej z kodem C# jedynie poprzez kopiowanie
print "Py: ", type(wartosc_), " wartosc_ = ", wartosc_
print "--- koniec skryptu Py ---"

# definicja funkcji w skrypcie dostepnej dla kodu C#:
def Funkcja(x1, x2):
   print "funkcja Py: ", type(x1), " x1 = ", x1, "; ", type(x2), " x2 = ", x2
   return x1*(x1+x2)

# definicja klasy w skrypcie dostepnej dla kodu C#:
class Klasa(object):
   def __init__(self, x):
       print "klasa Py: ", type(x), " x = ", x
       self.pole = x
