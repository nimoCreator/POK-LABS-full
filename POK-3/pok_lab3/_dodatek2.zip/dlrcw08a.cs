/**********************************************************/
/* Dowiazanie bibliotek CLR w skrypcie Pythona parsowanym */
/* w aplikacji DLR - kod C# programu glownego z okienkami */
/**********************************************************/

// przestrzenie nazw z biblioteki systemowej .NET Framework:
using System;
using System.IO;
using System.Reflection;

// przestrzenie nazw z interfejsu IronPython Microsoft API:
using IronPython;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

// przestrzen elementow wlasnych aplikacji:
namespace Cwiczenia 
{
 public class Program // glowna klasa programu
 {
  // glowna metoda z punktem wejscia do programu powloki interpretera:
  static int Main()
  {          
   var parser = Python.CreateEngine(); // utworzenie parsera jezyka Python
   Console.Write("Podaj sciezke do skryptu Py: ");
   string skrypt = Console.ReadLine(); // odczytanie i przetworzenie sciezki do wejsciowego pliku tekstowego zawierajacego skrypt jezyka Python
   if (!Path.HasExtension(skrypt)) 
   skrypt = Path.ChangeExtension(skrypt, ".py"); // dodanie koncowki do pliku dla skryptow Py
   if (!File.Exists(skrypt)) { // jezeli plik nie istnieje w podanym katalogu, to odszukanie go w katalogu domowym programu
    string domowy = Path.GetDirectoryName(typeof(Program).Assembly.Location);
    skrypt = Path.Combine(domowy, Path.GetFileName(skrypt));
    if (!File.Exists(skrypt)) { // lub odszukanie go w katalogu roboczym (biezacym)
     string roboczy = Directory.GetCurrentDirectory();
     skrypt = Path.Combine(roboczy, Path.GetFileName(skrypt));
     if (!File.Exists(skrypt)) { // w przeciwnym razie zakonczenie programu
      Console.WriteLine("Nie mozna odnalezc pliku: {0}", Path.GetFileName(skrypt));
      return -1;
     }
    }
   }
   var modul = parser.CreateScriptSourceFromFile(skrypt); // utworzenie docelowego modulu ze skryptem zrodlowym jezyka Python
   dynamic rezultat = modul.Execute(); // wykonanie modulu przez interpreter jezyka Python i zwrocenie rezulatu dynamicznego
   if (rezultat != null)
   Console.WriteLine("Koncowy rezultat wykonania: {0}", parser.Operations.Format(rezultat));
   Console.WriteLine();
   Console.WriteLine(">>>> KONIEC <<<<");
   Console.ReadLine(); 
   return 0; 
  }
 }
}


