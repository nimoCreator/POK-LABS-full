/***************************************************************************/
/* Integracja oprogramowania aplikacji C# w srodowisku skryptowym Python   */
/* - podzespol glownego programu powloki dla polecen uzytkownika aplikacji */
/***************************************************************************/

// przestrzenie nazw z biblioteki systemowej oraz interfejsu IronPython Microsoft API:
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using IronPython;
using IronPython.Hosting;
using Microsoft.Scripting;
using Microsoft.Scripting.Hosting;

// przestrzen elementow wlasnych aplikacji:
namespace Cwiczenia
{
 public class Powloka // glowna klasa z danymi i kodem programu powloki
 {
  public int a, b;

  public int Test1(int x)
  {
   Console.WriteLine("\nPowloka.Test1: x = {0}", x);
   Console.WriteLine("               (a,b) = ({0},{1})", a, b);
   return x * (a + b);
  }

  internal Powloka()
  {
   a = 10;
   b = 20;
  }

  public Assembly laduj(string plik) // operacje systemowe do wykonania w srodowisku skryptowym aplikacji
  {
   return this.ZaladujZespol(plik);
  }

  public object tworz(string plik, string typ, params object[] dane)
  {
   return this.UtworzObiekt(plik, typ, dane);
  }

  public string czytaj(string plik)
  {
   return this.OdczytajTekst(plik);
  }

  // glowna metoda z punktem wejscia do programu bedacego powloka interpretacji skryptow z poleceniami uzytkownika:
  internal static int Main()
  {
   try
   {
    ScriptEngine parser = Python.CreateEngine(); // utworzenie parsera Python bedacego glownym silnikiem jezyka 'IronPython' do translacji i wykonywania skryptow Py
    ScriptRuntime kernel = parser.Runtime; // wykonywanie skryptow przez silnik zachodzi w srodowisku uruchomieniowym bedacym kernelem jezyka 'IronPython'
    ScriptHost platforma = kernel.Host; // kernel osadzony jest we wspolnym srodowisku jezykow dynamicznych CLR/DLR platformy .NET
    Powloka Powloka = new Powloka(platforma); // utworzenie obiektu powloki dla aplikacji platformy .NET
    Powloka.Bieg(kernel, parser); // wykonanie interakcji z uzytkownikiem w powloce
    Powloka.Koniec(); // normalne zakonczenie procesu aplikacji
    return 0;
   }
   catch (Exception wyjatek) // w razie awarii...
   {
    Powloka.Przerwanie(wyjatek); // ...przerwanie procesu aplikacji
    return -1;
   }
  }

  // przetwarzanie interakcji w skryptowym interfejsie uzytkownika programu:

  private readonly string zacheta;
  private readonly string postep;
  private readonly string nakaz;
  private readonly PlatformAdaptationLayer system;

  private Powloka(ScriptHost platforma) : this()
  {
   this.zacheta = ">>> "; // symbol zachety do wprowadzenia tresci biezacej linii w powloce
   this.postep = "... "; // symbol postepu wprowadzania tekstu w kolejnych liniach powloki
   this.nakaz = "$"; // symbol nakazujacy wykonanie polecenia w linii powloki przez aplikacje
   this.system = platforma.PlatformAdaptationLayer; // warstwa abstrakcji systemu operacyjnego
   Console.WriteLine();
   Console.WriteLine("Wprowadz polecenie (np. help) lub nacisnij ENTER, aby edytowac/wykonac skrypt...");
  }

  private void Bieg(ScriptRuntime kernel, ScriptEngine parser)
  {
   string polecenie = null;
   Exception wyjatek = null;
   object rezultat = null;
   string skrypt = null;
   ScriptSource zrodlo = null;
   List<string> historia = new List<string>();
   bool biegnij = true;
   do
   {
    try
    { // interakcja z uzytkownikiem w linii powloki:
     Console.WriteLine();
     Console.Write(zacheta + nakaz); // przod linii ze symbolami zachety podania i nakazu wykonania polecenia
     polecenie = Console.ReadLine().Trim().ToLower(); // odczytanie polecenia dla aplikacji bez wiodacych/konczacych spacji, male znaki
     if (polecenie.StartsWith(nakaz))
      polecenie = polecenie.Substring(polecenie.LastIndexOf(nakaz) + nakaz.Length).TrimStart(); // wlasciwa tresc polecenia bez symboli nakazu oraz bez wiodacych spacji
     if (polecenie == null) continue;
     else if (polecenie == "help") DrukujPomoc(parser); // polecenie wyswietlenia tekstu pomocy
     else if (polecenie == "info") DrukujRaport(parser, zrodlo, rezultat, wyjatek); // polecenie wyswietlenia tekstu raportu
     else if (polecenie == "quit") { biegnij = false; polecenie = null; } // polecenie zakonczenia petli interakcyjnej
     else if (polecenie == "exit") { biegnij = false; historia = null; } // polecenie wyjscia z interakcji bez wyswietlania historii
     else if (polecenie != "" && !(new string[] { "edit", "load", "read", "exec" }).Any(napis => polecenie.Contains(napis)))
     { // w przeciwnym razie polecenie jest nieznane
      Console.WriteLine("\nostrzezenie: nieznane polecenie aplikacji!");
      polecenie = null;
     }
     else
     { // przetwarzanie nowego lub poprzedniego skryptu:
      if (polecenie == "edit") polecenie = "";
      else
      {
       if (polecenie != "") polecenie = nakaz + polecenie;
       skrypt = null;
      }
      wyjatek = null;
      rezultat = null;
      skrypt = EdytujTekst(kernel, polecenie, skrypt); // interaktywna edycja tekstu zawierajacego skrypt jezyka Python
      zrodlo = null;
      if (!String.IsNullOrWhiteSpace(skrypt))
      {
       ScriptSource zrodlowy = parser.CreateScriptSourceFromString(skrypt); // utworzenie modulu zrodlowego zawierajacego podana tresc skryptu
       zrodlo = zrodlowy;
       CompiledCode wynikowy = zrodlowy.Compile(); // jawna kompilacja zrodla do kodu wynikowego
       ScriptScope zakres = parser.CreateScope(); // utworzenie pustego zakresu definicyjnego
       { // zdefiniowanie w zakresie nowych zmiennych obiektowych z dynamicznym dostepem do elementow ich klas - dostep ten bedzie mozliwy poprzez p/w skrypt dynamicznego jezyka Python
        Powloka powlok = this;
        zakres.SetVariable("_parser", parser); // obiekt parsera jezykowego
        zakres.SetVariable("_kernel", kernel); // obiekt kernela uruchomieniowego
        zakres.SetVariable("_system", system); // obiekt systemu operacyjnego
        zakres.SetVariable("_powlok", powlok); // obiekt powloki programowej
       }
       dynamic zwrot = wynikowy.Execute(zakres); // wykonanie wynikowego kodu w podanym zakresie i zwrocenie dynamicznego obiektu rezultatu
       rezultat = zwrot;
      }
     }
     if (historia != null && !String.IsNullOrEmpty(polecenie)) // zapamietanie biezacego polecenia w historii polecen powloki
      historia.Add(polecenie);
    }
    catch (Exception x)
    { // blad przetwarzania polecenia lub skryptu
     polecenie = null;
     skrypt = null;
     wyjatek = x;
     Console.WriteLine("\nblad: {0}!", wyjatek.Message);
    }
   } while (biegnij);
   if (historia != null && historia.Count > 0)
   { // wydruk wszystkich polecen w historii interakcji z uzytkownikiem
    Console.WriteLine();
    Console.WriteLine("historia polecen : \n");
    foreach (string wpis in historia)
     Console.WriteLine(wpis);
   }
  }

  private void Koniec()
  {
   Console.WriteLine();
   Console.WriteLine(">>>> KONIEC <<<<");
   Console.ReadLine();
  }

  private static void Przerwanie(Exception wyjatek)
  {
   Console.WriteLine("\nawaria: {0}!", wyjatek.Message);
   Console.WriteLine();
   Console.WriteLine(">>>> PRZERWANIE <<<<");
   if (Console.ReadLine() == " ") // przerwanie procesu aplikacji i wpisanie uwagi do dziennika systemowego aplikacji
    Environment.FailFast("Aplikacja nie moze przetwarzac interakcji w srodowisku skryptowym \'" + typeof(Python).ToString() + "\'.");
  }

  private string EdytujTekst(ScriptRuntime kernel, string linia, string tekst)
  {
   string przod = tekst == null ? zacheta : postep; // przod pierwszej linii powloki ze symbolem zachety lub postepu edycji tekstu
   bool edytuj = true;
   do
   { // edycja wejsciowego tekstu w kolejnych liniach powloki:
    if (String.IsNullOrWhiteSpace(linia))
    {
     Console.Write(przod); // drukuj symbol poprzedzajacy linie powloki  
     linia = Console.ReadLine(); // odczytanie biezacej linii powloki, gdy poprzednia byla bez tresci
    }
    if (String.IsNullOrEmpty(linia)) { edytuj = false; linia = null; } // zakonczenie petli edycyjnej, gdy linia powloki jest pusta
    else
    {
     string polecenie = linia.TrimStart().ToLower(); // sformatowanie polecenia dla aplikacji bez wiodacych spacji, male znaki
     if (polecenie.StartsWith(nakaz))
     { // poprzedzenie polecenia symbolem nakazu jego wykonania
      linia = "# " + polecenie; // wstawienie do wiersza skryptowego komentarza z poleceniem
      polecenie = (polecenie + "#").Remove((polecenie + "#").IndexOf('#')).TrimEnd().Substring(polecenie.LastIndexOf(nakaz) + nakaz.Length).TrimStart(); // wlasciwa tresc polecenia bez koncowego komentarza, bez konczacych spacji, bez symboli nakazu oraz bez wiodacych spacji
      if (polecenie.StartsWith("load"))
      { // polecenie ladowania nowego modulu
       string nazwa = (polecenie + " ").Substring((polecenie + " ").IndexOf(' ') + 1).Trim(); // nazwa modulu jako argument polecenia bez wiodacych/konczacych spacji
       Assembly pakiet = ZaladujZespol(nazwa); // zaladowanie zewnetrznego modulu DLL o podanej nazwie jako podzespol do domeny aplikacji 
       if (pakiet != null) kernel.LoadAssembly(pakiet); // zbindowanie zaladowanego pakietu ze srodowiskiem skryptowym
       else linia = null; // w razie bledu anulowanie polecenia z wiersza skryptowego
      }
      else if (polecenie.StartsWith("read"))
      { // polecenie czytania nowego skryptu
       string nazwa = (polecenie + " ").Substring((polecenie + " ").IndexOf(' ') + 1).Trim(); // nazwa skryptu jako argument polecenia bez wiodacych/konczacych spacji
       string tresc = OdczytajTekst(nazwa); // odczytanie zewnetrznego skryptu Py o podanej nazwie z pliku tekstowego w pamieci masowej 
       if (tresc != null) linia += "\n###############\n\n" + tresc + "\n\n###############"; // wstawienie odcztanej tresci do tekstu skryptowego
       else linia = null; // w razie bledu anulowanie polecenia z wiersza skryptowego
      }
      else if (polecenie.StartsWith("exec"))
      { // jawne polecenie zakonczenia edycji i przejscia do wykonywania biezacego skryptu
       edytuj = false;
       Console.WriteLine();
       Console.Write("wynik: ");
       linia = null;
      }
      else
      {
       Console.WriteLine("ostrzezenie: nieznane polecenie skryptowe!");
       linia = null;
      }
     }
    }
    if (linia != null)
    { // wstawienie linii z podana trescia do biezacego wiersza w tekscie skryptowym  
     string wiersz = linia + "\n";
     if (tekst == null) tekst = wiersz;
     else tekst += wiersz;
     linia = null;
    }
    przod = postep; // przod nastepnej linii powloki ze symbolem postepu w edycji tekstu 
   } while (edytuj);
   return tekst;
  }

  private static string SzukajPlik(string nazwa, string typ)
  {
   if (String.IsNullOrWhiteSpace(nazwa)) return null;
   string plik = Path.HasExtension(nazwa) ? nazwa : Path.ChangeExtension(nazwa, typ); // dodanie typu pliku do jego nazwy 
   if (!File.Exists(plik))
   { // jezeli plik nie istnieje w podanym katalogu, to odszukanie go w katalogu domowym powloki
    string domowy = Path.GetDirectoryName(typeof(Powloka).Assembly.Location);
    plik = Path.Combine(domowy, Path.GetFileName(plik));
    if (!File.Exists(plik))
    { // lub odszukanie go w katalogu roboczym uzytkownika
     string roboczy = Directory.GetCurrentDirectory();
     plik = Path.Combine(roboczy, Path.GetFileName(plik));
     if (!File.Exists(plik))
     { // lub odszukanie go w nadrzednym katalogu wzgledem katalogu roboczego
      string nadrzedny = Directory.GetParent(roboczy).FullName;
      plik = Path.Combine(nadrzedny, Path.GetFileName(plik));
      if (!File.Exists(plik))
      { // w przeciwnym razie zakonczenie poszukiwan niepowodzeniem
       Console.WriteLine("uwaga: plik \'{0}\' nie istnieje.", Path.GetFileName(plik));
       return null;
      }
     }
    }
   }
   return plik;
  }

  private Assembly ZaladujZespol(string modul)
  {
   Assembly zespol = null;
   string plik = SzukajPlik(modul, ".dll"); // odszukanie podanego modulu w pamieci masowej i zwrocenie sciezki do jego pliku .dll
   if (plik != null)
    zespol = Assembly.LoadFrom(plik); // zaladowanie modulu z pliku w postaci podzespolu domeny aplikacji
   if (zespol == null)
    Console.WriteLine("ostrzezenie: nie mozna zaladowac zespolu modulu z pliku .dll!");
   return zespol;
  }

  private object UtworzObiekt(string pakiet, string klasa, params object[] argumenty)
  {
   object obiekt = null;
   Assembly zespol = ZaladujZespol(pakiet); // zaladowanie podanego pakietu do domeny aplikacji i zwrocenie referencji do jego zespolu 
   if (zespol != null)
   {
    Type typ = zespol.GetType(klasa, false); // odszukanie (bez wyjatkow) podanej klasy pakietowej w przestrzeni publicznych nazw i zwrocenie jej typu 
    if (typ != null && typ.IsClass)
     obiekt = Activator.CreateInstance(typ, argumenty); // utworzenie obiektu dla podanych argumentow udostepniajacego publiczne dane i kod pakietu
   }
   if (obiekt == null)
    Console.WriteLine("ostrzezenie: nie mozna utworzyc obiektu klasy z zespolu pakietowego!");
   return obiekt;
  }

  private string OdczytajTekst(string skrypt)
  {
   string tekst = null;
   string plik = SzukajPlik(skrypt, ".py"); // odszukanie podanego skryptu w pamieci masowej i zwrocenie sciezki do jego pliku .py
   if (plik != null)
   {
    StreamReader wejscie = new StreamReader(plik); // utworzenie strumienia wejsciowego do odczytu z pliku
    tekst = wejscie.ReadToEnd(); // odczytanie skryptu z pliku w postaci tekstu 
   }
   if (String.IsNullOrEmpty(tekst))
    Console.WriteLine("ostrzezenie: nie mozna odczytac tekstu skryptu z pliku .py!");
   return tekst;
  }

  private void DrukujPomoc(ScriptEngine parser)
  {
   Console.WriteLine(); // opis glownych polecen wykonywanych w powloce przez aplikacje
   Console.WriteLine("polecenia aplikacji:");
   Console.WriteLine("  {0}help - wyswietlenie opisu srodowiska", nakaz);
   Console.WriteLine("  {0}edit - rozpoczecie/kontynuacja edycji", nakaz);
   Console.WriteLine("  {0}info - wyswietlenie raportu przetwarzania", nakaz);
   Console.WriteLine("  {0}quit - zakonczenie i podsumowanie interakcji", nakaz);
   Console.WriteLine("  {0}exit - natychmiastowe wyjscie z powloki", nakaz);
   Console.WriteLine(); // opis dodatkowych polecen wykonywanych przez aplikacje w trakcie edycji skryptu
   Console.WriteLine("polecenia skryptowe:");
   Console.WriteLine("  {0}load plik - ladowanie modulu z pliku i wstawienie jego typow do skryptu", nakaz);
   Console.WriteLine("  {0}read plik - odczytanie skryptu z pliku i wstawienie jego tresci do skryptu", nakaz);
   Console.WriteLine("  {0}exec - wykonanie biezacego skryptu i wyswietlenie jego wyniku", nakaz);
   Console.WriteLine(); // opis pomocniczych obiektow wbudowanych do srodowiska skryptowego
   Console.WriteLine("obiekty skryptu do uzycia elementow:");
   Console.WriteLine(" _powlok - powloki programowej");
   Console.WriteLine(" _parser - parsera jezykowego");
   Console.WriteLine(" _kernel - kernela uruchomieniowego");
   Console.WriteLine(" _system - systemu operacyjnego");
   Console.WriteLine(); // opis systemowych operacji wywolywanych w srodowisku skryptowym
   Console.WriteLine("wybrane operacje skryptu dla p/w obiektow:");
   Console.WriteLine(" _powlok.laduj('plik') - ladowanie modulu z pliku w postaci zespolu");
   Console.WriteLine(" _powlok.czytaj('plik') - czytanie skryptu z pliku w postaci tekstu");
   Console.WriteLine(" _powlok.tworz('plik','typ'[,dane]) - tworzenie pakietu z danymi w postaci obiektu klasy z pliku");
   Console.WriteLine();
   try
   { // opis parsera uzywanego do interpretacji skryptow w powloce aplikacji
    Console.WriteLine("jezyk skryptow: {0} / {1}", parser.Setup.Names[1], parser.Setup.FileExtensions[0]);
    Console.WriteLine("parser jezyka: {0}", parser.Setup.Names[0]);
    Console.WriteLine("wersja parsera: {0}", parser.LanguageVersion);
   }
   catch
   {
    Console.WriteLine("parser jezyka skryptow: {0}", parser.Setup.DisplayName);
   }
   Console.WriteLine(); // lista nazw zdefiniowanych elementow parsera
   Console.WriteLine("nazwy predefiniowane jezyka:");
   foreach (var nazwa in parser.GetBuiltinModule().GetVariableNames())
    Console.Write("{0} ", nazwa); Console.WriteLine(); // predefiniowane nazwy elementow z standardowej biblioteki jezyka Python
   Console.WriteLine();
   Console.WriteLine("nazwy biblioteki systemowej:");
   foreach (var nazwa in parser.GetSysModule().GetVariableNames())
    Console.Write("{0} ", nazwa); Console.WriteLine(); // nazwy glownych elementow z systemowej biblioteki jezyka Python
   Console.WriteLine();
   Console.WriteLine("nazwy srodowiska CLR:");
   foreach (var nazwa in parser.GetClrModule().GetVariableNames())
    Console.Write("{0} ", nazwa); Console.WriteLine(); // nazwy pomocniczych elementow z systemowej biblioteki srodowiska CLR
   Console.WriteLine(); // lista sciezek dostepu do zewnetrznych modulow
   Console.WriteLine("sciezki dostepu do modulow:");
   foreach (var x in parser.GetSearchPaths())
   {
    string sciezka = x;
    if (sciezka == ".") sciezka = system.CurrentDirectory;
    Console.WriteLine("{0} ", sciezka);
   }
  }

  private void DrukujRaport(ScriptEngine parser, ScriptSource zrodlo, object rezultat, Exception wyjatek)
  {
   Console.WriteLine();
   Console.WriteLine("interpreter wejsciowy: {0}", parser.Setup.DisplayName);
   if (zrodlo != null)
   { // wydruk opisu zrodla
    Console.WriteLine("skrypt o zrodle typu '{0}' :", zrodlo.Kind);
    int numer = 0;
    do
    { // wydruk linii skryptu zrodlowego
     string linia = zrodlo.GetCodeLine(++numer);
     if (linia == null) numer = -1;
     else Console.WriteLine("{0,3} | {1}", numer, linia);
    } while (numer >= 0);
    Console.WriteLine("stan parsowania skryptu: {0}", zrodlo.GetCodeProperties());
   }
   Console.WriteLine("katalog roboczy systemu: {0}", system.CurrentDirectory);
   if (rezultat != null)
   { // wydruk opisu rezultatu
    Console.WriteLine("rezultat wykonywania: {0}", parser.Operations.Format(rezultat));
    Console.WriteLine("typ rezultatu skryptu: {0}", rezultat.GetType());
   }
   Console.WriteLine();
   if (wyjatek != null)
   { // wydruk opisu wyjatku
    Console.WriteLine("przetwarzanie skryptu zawiodlo!");
    Console.WriteLine("przyczyna wyjatku: {0}", wyjatek.Source);
    Console.WriteLine("miejsce wyjatku: {0}", wyjatek.TargetSite);
    Console.WriteLine("opis wyjatku: {0}", wyjatek.Message);
    Console.WriteLine("historia wyjatku :\n{0}", wyjatek.StackTrace);
   }
   else
    Console.WriteLine("brak bledow w przetwarzaniu skryptowym...");
  }
 }
}
