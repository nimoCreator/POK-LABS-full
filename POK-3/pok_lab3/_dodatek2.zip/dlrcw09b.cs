/*************************************************************************/
/* Integracja oprogramowania aplikacji C# w srodowisku skryptowym Python */
/* - podzespol dodatkowego modulu aplikacji bedacy pakietem w srodowisku */
/*************************************************************************/

// przestrzenie nazw z biblioteki systemowej:
using System;

// przestrzen elementow wlasnych aplikacji:
namespace Cwiczenia
{
 public class Pakiet1 // glowna klasa z danymi i kodem modulu bedacego pakietem srodowiska
 {
  public int a, b;

  public int Test1(int x)
  {
   Console.WriteLine("\nPakiet1.Test1: x = {0}", x);
   Console.WriteLine("               (a,b) = ({0},{1})", a, b);
   return x + a * b;
  }

  public Pakiet1()
  {
   a = 10;
   b = 20;
  }
 }
}
