/****************************************************/
/* Uzycie parsera IronPython w aplikacji konsolowej */
/* dla srodowiska DLR - kod C# programu glownego    */
/****************************************************/

// przestrzenie nazw z biblioteki systemowej .NET Framework:
using System;
using System.IO;
using System.Reflection;
using System.Dynamic;

// przestrzenie nazw z interfejsu IronPython Microsoft API:
using IronPython;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

// przestrzen elementow wlasnych aplikacji:
namespace Cwiczenia
{
 public class Program // glowna klasa programu
 {
  // glowna metoda z punktem wejscia do programu konsolowego bedacego powloka interpretacji skryptow:
  static int Main()
  {
   Console.WriteLine("+++ prolog kodu C# +++");
   var zmienna = 123; // zdefiniowanie prostej zmiennej o niejawnym statycznym typie wyznaczonym jednokrotnie na podstawie przypisanego wyrazenia poczatkowego
   Console.WriteLine("C#: {0} zmienna = {1}", zmienna.GetType(), zmienna.ToString());

   dynamic obiekt = new ExpandoObject(); // utworzenie rozszerzalnego obiektu o typie dynamicznym z mozliwoscia dowolnej zmiany jego skladnikow  
   Console.WriteLine("C#: {0} obiekt = {1}", obiekt.GetType(), obiekt.ToString());

   obiekt.pole = 234; // dodanie nowego pola do dynamicznego obiektu
   Console.WriteLine("C#: {0} obiekt.pole = {1}", obiekt.pole.GetType(), obiekt.pole.ToString());

   obiekt.metoda = (Func<int, int>)delegate (int x) { // dodanie nowej metody jako delegacji anonimowej czyli call-back dla kodu C#
    Console.WriteLine("metoda C#: {0} x = {1}", x.GetType(), x.ToString());
    return 2 * x + 1;
   };

   var parser = Python.CreateEngine(); // utworzenie parsera jezyka Python
   var zakres = parser.CreateScope(); // utworzenie pustego zakresu definicyjnego
   zakres.SetVariable("_zmienna", zmienna); // zdefiniowanie w zakresie skryptu nowych elementow powiazanych z kodem C# umozliwiajacych dynamiczny dostep poprzez p/w skrypt dynamicznego jezyka Python
   zakres.SetVariable("_obiekt", obiekt); // jedynie obiekty sa powiazane poprzez referencje w zakresie, proste zmienne j/w sa kopiowane do zakresu

   Console.Write(">>> podaj sciezke do skryptu: ");
   var skrypt = Console.ReadLine(); // odczytanie sciezki do wejsciowego pliku tekstowego zawierajacego skrypt jezyka Python
   var modul = parser.CreateScriptSourceFromFile(skrypt); // utworzenie docelowego modulu ze skryptem zrodlowym jezyka Python

   dynamic rezultat = modul.Execute(zakres); // bezposrednie wykonanie modulu przez interpreter jezyka Python w podanym zakresie definicyjnym
   if (rezultat == null) Console.WriteLine("rezultat wykonania skryptu: null"); // w rezultacie wykonania moze byc zwrocony obiekt koncowej wartosci typu dynamicznego, znanego interpreterowi na podstawie operacji zapisanych w skrypcie
   else Console.WriteLine("rezultat wykonania skryptu: {0}", parser.Operations.Format(rezultat));

   Console.WriteLine("--- epilog kodu C# ---");
   dynamic wartosc = zakres.GetVariable("wartosc_"); // dynamiczne pobranie ze zakresu wykonanego skryptu elementow do kodu C#, np. globalnej zmiennej o podanej nazwie
   Console.WriteLine("C#: {0} wartosc = {1}", wartosc.GetType(), wartosc.ToString());
   Console.WriteLine("C#: {0} zmienna = {1}", zmienna.GetType(), zmienna.ToString());
   Console.WriteLine("C#: {0} obiekt = {1}", obiekt.GetType(), obiekt.ToString());
   Console.WriteLine("C#: {0} obiekt.pole = {1}", obiekt.pole.GetType(), obiekt.pole.ToString());
   Console.WriteLine("C#: {0} obiekt.pole2 = {1}", obiekt.pole2.GetType(), obiekt.pole2.ToString());
   dynamic a = obiekt.metoda2(789); // zwrotne wywolanie metody (ang. call-back) ze kodu C# do skryptu Py i otrzymanie dynamicznego wyniku
   Console.WriteLine("C#: {0} obiekt.metoda2(789) = {1}", a.GetType(), a.ToString());
   var funkcja = zakres.GetVariable<Func<object, object, object>>("Funkcja"); // dynamiczne pobranie funkcji globalnej o podanej sygnaturze i nazwie
   Console.WriteLine("C#: {0} funkcja = {1}", funkcja.GetType(), funkcja.ToString());
   dynamic b = funkcja(11, 22); // wywolanie funkcji z dynamicznym wynikiem 
   Console.WriteLine("C#: {0} funkcja(11, 22) = {1}", b.GetType(), b.ToString());
   var klasa = zakres.GetVariable<Func<object, object>>("Klasa"); // dynamiczne pobranie klasy publicznej o podanej sygnaturze konstruktora i nazwie klasy
   Console.WriteLine("C#: {0} klasa = {1}", klasa.GetType(), klasa.ToString());
   var c = klasa("xyz"); // utworzenie instancji klasy poprzez proste wywolanie jej konstruktora
   Console.WriteLine("C#: {0} klasa(\"xyz\") = {1}", c.GetType(), c.ToString());
   dynamic d = parser.Operations.GetMember(c, "pole"); // refleksyjny dostep do dynamicznego pola instancji o podanej nazwie
   Console.WriteLine("C#: {0} klasa(\"xyz\").pole = {1}", d.GetType(), d.ToString());

   Console.WriteLine();
   Console.WriteLine(">>>> KONIEC <<<<");
   Console.ReadLine();
   return 0;
  }
 }
}
