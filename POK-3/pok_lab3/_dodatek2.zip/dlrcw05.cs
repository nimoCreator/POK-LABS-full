/****************************************/
/* Programowanie dynamiczne w jezyku C# */
/****************************************/

// przestrzenie nazw z biblioteki systemowej:
using System;
using System.Linq; // wsparcie do przetwarzania kwerend
using System.Collections; // kolekcje zwykle i generyczne
using System.Collections.Generic;
using System.Reflection; // wsparcie programowanie refleksywnego przez CLR
using System.Dynamic; // wsparcie programowanie dynamicznego przez DLR

// przestrzen elementow wlasnych programu:
namespace Cwiczenia
{
 public class Program // glowna klasa programu
 {

  // funkcje testujace statyczne rozpoznawanie typow przez dedukcje kompilatora:

  static void Test1<T>(T x) // kompilator wydedukuje typ parametru na podstawie symbolicznego typu generyka 'T', tu nie mozna uzyc typu niejawnego: var x
  {
   Console.WriteLine("test1: {0} x = {1}", x.GetType(), x.ToString());
  }

  static object Test2<T, U>(T x, U y) // nalezy poinformowac kompilator jak ma ograniczyc typy rezultatu aby mozna bylo wyznaczyc typ rezultatu funkcji ale poniewaz nie mozna tu tez uzyc typu niejawnego var wiec typ rezultatu musi byc nieokreslonym obiektem 'object' lub typem dynamicznym 'dynamic'
   where T : IEquatable<T> where U : IEquatable<U>
  {
   return x.Equals(y) ? (object)x : (object)y; // x * (x + y) / y; // niestety w generykach nie mozna wykonywac dzialan arytmetycznych a jedynie proste operacje dopuszczone przez p/w wiezy podane za slowem where jako interfejsy np dla operacji rownosci
  }

  // glowna metoda programu:
  static int Main()
  {
   // przyklady statycznego (pseudo-dynamicznego) programowania w C# z uzyciem niejawnego typu 'var' i generykow:

   int a = 5; // zmienna o podanym jawnie typie statycznym 'int' znanym w czasie kompilacji (statyczna typizacja)                                                   
   Console.WriteLine("test1: {0} a = {1}", a.GetType(), a.ToString());
   Test1(a);

   var b = 7.5; // nieokreslony typ niejwany 'var' zostanie wydedukowany statycznie przez kompilator na podstawie znanego typu wyrazenia przypisania (odpowiednik typu 'auto' ze C++)
   Console.WriteLine("test2: {0} b = {1}", b.GetType(), b.ToString());
   var c = Test2(a, b); // tu kompilator zamiast dedukcji moze przekazac srodowisku CLR/DLR rozpoznanie typu samego wyrazenia w czasie dzialania programu, gdyz pojawia sie tu niejawnie typ 'obiect' lub 'dynamic' dla rezultatu funkcji
   Console.WriteLine("test2: {0} c = {1}", c.GetType(), c.ToString());

   var rekord = new { pole1 = 11, pole2 = 22 }; // tu kompilator tworzy rekord o dwoch polach jako obiekt anonimowego typu referencyjnego znanego jedynie kompilatorowi
   Console.WriteLine("rekord: {0} rekord = {1}", rekord.GetType(), rekord.ToString());
   var krotka = ("abc", 123); // tu kompilator od wersji C#7.0 tworzy krotke o dwoch danych typu string oraz int ale jest to obiekt jawnego wartosciowego typu zlozonego ktory mozna tez zapisac w postaci: (string, int)
   Console.WriteLine("krotka: {0} krotka = {1}", krotka.GetType(), krotka.ToString());
   var kwerenda = from x in "a2c4d" where char.IsDigit(x) select x; // tu kompilator tworzy kwerende jako symboliczne drzewo wyrazeniowe lub obiekt delegacji do kodu a wiec pewien obiekt o typie referencyjnym znanym jedynie kompilatorowi a dostepnym rowniez poprzez interfejsy np. IEnumerable 
   Console.WriteLine("kwerenda: {0} kwerenda = {1}", kwerenda.GetType(), kwerenda.ToString());
   // uwaga: inne zastosowania typu 'var' sa zabronione lub ograniczone w C#, np. dla wyrazenia lambdy, anonimowej delegacji

   // przyklady dynamicznego programowania w C# z uzyciem mechnizmu refleksi typow (programowanie refleksyjne, dynamiczna typizacja):

   int d = 17; // tu mozna zmienic typ j/n
   // char d = 'A';
   Console.WriteLine("test3: {0} d = {1}", d.GetType(), d.ToString());
   object e = Test3(d); // nieokreslony obiekt zmiennej, ktorego typ zostanie rozpoznany dynamicznie w czasie dzialania programu 
   Console.WriteLine("test3: {0} e = {1}", e.GetType(), e.ToString());

   //object f = Test3(a); // brak mozliwosci wykonania dzialania + dla zmiennych typu object nawet wtedy gdy zmienne ta sa ukrytymi liczbami (ang. boxing)
   //object g = Test3(b); // chyba ze tu zastosuje sie refleksje typu j/n i jawne rzutowanie do typu liczbowego
   //object h = f + g; // wtedy z typu object mozna otrzymac jawnie typ liczbowy ktory pozwala na wykonanie dzialania dodawania 

   try
   {
    Object obiekt = Test4(); // nieokreslony obiekt klasy
    Type typ = obiekt.GetType(); // dostep do typu klasy obiektu
    FieldInfo pole = typ.GetField("pole"); // pobranie informacji o polu klasy
    pole.SetValue(obiekt, 123); // ustawienie wartosci pola
    MethodInfo metoda = typ.GetMethod("metoda"); // pobranie informacji o metodzie klasy
    Object wynik = metoda.Invoke(obiekt, new Object[] { 12, 15 }); // wywolanie metody z dwoma argumentami i otrzymanie wyniku
    Console.WriteLine("test4: {0} metoda = {1}", wynik.GetType(), wynik.ToString());
    Object wartosc = pole.GetValue(obiekt); // odczytanie wartosci pola
    Console.WriteLine("test4: {0} pole = {1}", wartosc.GetType(), wartosc.ToString());
   }
   catch
   {
    Console.WriteLine("test4: blad w programowaniu refleksyjnym!");
   }

   // przyklady w pelni dynamicznego programowania w C# z uzyciem dynamicznego typu 'dynamic':

   try
   {
    dynamic f = Test5(a); // dynamiczny typ danych ktorego rozpoznanie zostanie przez kompilator przekazane do uruchomieniowego srodowiska DLR i wykonane w czasie dzialania programu nawet jezeli wyrazenie za znakiem = ma statyczny jawny typ znany kompilatorowi (w C++/CLI brak jest wsparca dla typu dynamic)
    Console.WriteLine("test5: {0} f = {1}", f.GetType(), f.ToString());
    dynamic g = Test5(b);
    //dynamic g = Test5("b"); // w tym przypadku dynamiczne dodawanie ponizej nie bedzie wykonane co wywola wyjatek
    Console.WriteLine("test5: {0} g = {1}", g.GetType(), g.ToString());
    dynamic h = f + g; // tu srodowisko DLR sparsuje wyrazenie o dynamicznej ewaluacji (wywolaniu) i na podstawie tego w czasie dzialania programu zostanie wykonane dzialanie + na operandach o ile ich dynamiczny typ na to pozwala w przeciwny razie zostanie zgloszony wyjatek, przy czym wynik moze byc skaszowany przez DLR w celu przyspieszenie nastepnych podobnych dzialan
    Console.WriteLine("test5: {0} h = {1}", h.GetType(), h.ToString());
   }
   catch
   {
    Console.WriteLine("test5: dynamiczne dodawanie jest zabronione!");
   }

   try
   {
    var i = Test5(123); // zamiast jawnego typu dynamicznego moze byc podany typ niejawny var ktory ukrywa slowo dynamic
    //var i = Test5(12.3); // typ double nie bedzie konwertowany dynamicznie ponizej co wywola wyjatek
    Console.WriteLine("test5: {0} i = {1}", i.GetType(), i.ToString());
    object j = i; // typ dynamic jest wprost rownowazny typowi object
    Console.WriteLine("test5: {0} j = {1}", j.GetType(), j.ToString());
    int k = i; // tu DLR wykona konwersje niejawna o ile w czasie dzialania programu zmienna zrodlowa ma docelowy typ int
    Console.WriteLine("test5: {0} k = {1}", k.GetType(), k.ToString());
   }
   catch
   {
    Console.WriteLine("test5: dynamiczna konwersja jest zabroniona!");
   }

   try
   {
    dynamic obiekt = Test6(); // zmienna o dynamicznym typie ktory jest tu przewidywany jako klasa rozpoznawana dynamicznie a zadeklarowana w programie z ponizszymi skladnikami lub umozliwiajaca ich dynamiczne tworzenie  
    obiekt.pole = 123; // ustawienie wartosci pola
    dynamic wynik = obiekt.metoda(12, 15); // wywolanie metody z dwoma argumentami i otrzymanie wyniku
    Console.WriteLine("test6: {0} metoda = {1}", wynik.GetType(), wynik.ToString());
    dynamic wartosc = obiekt.pole; // odczytanie wartosci pola
    Console.WriteLine("test6: {0} pole = {1}", wartosc.GetType(), wartosc.ToString());
   }
   catch
   {
    Console.WriteLine("test6: blad w dynamicznym programowaniu!");
   }

   Console.WriteLine();
   Console.WriteLine(">>>> KONIEC <<<<");
   Console.ReadLine();
   return 0;
  }

  // funkcje testujace dynamiczne rozpoznawanie typow poprzez mechanizm refleksji typow srodowiska CLR:

  static object Test3(object x) // nieokreslony obiekt parametru i stad rezultatu  
  {
   try
   { // badanie dynamiczne typu parametru w czasie dzialania programu
    int a = (int)x; // kowersja musi byc tu jawna
    return 5 * a;
   }
   catch
   {
    try
    {
     double b = (double)x;
     return 7.5 * b;
    }
    catch
    {
     return "<nieznany>";
    }
   }
  }

  struct Rekord
  { // pusty typ nie zawierajacy uzywanych we powyzszych przykladach skladnikow
  }

  class Klasa
  { // ten typ zawiera uzywane powyzej skladniki, ale aby spowodowac blad w przykladach...
   public int pole = 0; // ...mozna zmienic typ, nazwe lub prawa dostepu
   public double metoda(int x, int y) // ...mozna zmienic dodatkowo liste parametrow
   {
    return pole * (x + y);
   }
  };

  static object Test4() // nieokreslony obiekt rezultatu
  {
   // return new Rekord(); // zmiana typu tworzonego tu obiektu moze spowodowac blad w p/w przykladach
   return new Klasa();
  }

  // funkcje testujace dynamiczne rozpoznawanie i modyfikowanie typow z uzyciem srodowiska DLR dla jezykow dynamicznych:

  static dynamic Test5(dynamic x) // dynamiczny typ parametru oraz rezultatu  
  {
   try
   { // badanie dynamiczne typu parametru w czasie dzialania programu i wykonanie niejawnej konwersji
    int a = x;
    return 5 * a;
   }
   catch
   {
    try
    {
     double b = x;
     return 7.5 * b;
    }
    catch
    {
     return null;
    }
   }
  }

  class DynamicznaKlasa : DynamicObject
  { // ten typ moze dodatkowo zawierac dowolne skladniki przetwarzane dynamicznie w czasie uruchomienia programu
   Dictionary<string, object> skladniki = new Dictionary<string, object>(); // pamiec do przechowywania uzywanych skladnikow, jedynie dla skladowych pol

   // ... tu moga byc zdefiniowane jawne skladniki jak w zwyklej klasie ktore moga byc uzywane poprzez zwykla reflekse typu w CLR
   // natomiast w przypadku braku jawnej definicji srodowisko DLR wywola niejwanie jedna z ponizszych metod wirtualnych do przetwarzania dynamicznego obiektu 

   public override bool TryGetMember(GetMemberBinder binder, out object value)
   { // metoda probuje pobrac wartosc skladowego pola o podanej nazwie o ile bylo wczesniej uzywane w przeciwnym razie bedzie blad
    return skladniki.TryGetValue(binder.Name, out value);
   }

   public override bool TrySetMember(SetMemberBinder binder, object value)
   { // metoda probuje ustawic wartosc skladowego pola o podanej nazwie, nowego lub juz uzywanego
    skladniki[binder.Name] = value;
    return true;
   }

   public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
   { // metoda probuje wywolac skladowa funkcje przekazujac argumenty jej wywolania i pobierajac rezultat jej wykonania
    try
    {
     if (binder.Name == "metoda") // wywolanie funkcji o znanej nazwie spowoduje wykonanie odpowiedniego kodu i zwrot wyniku
     {
      int x = (int)args[0];
      int y = (int)args[1];
      int pole = 0;
      object member;
      if (skladniki.TryGetValue("pole", out member)) pole = (int)member;
      double wynik = pole * (x + y);
      result = wynik;
     }
     else throw null;
     return true;
    }
    catch // w przypadku wywolania nieznanej funkcji bedzie blad
    {
     result = null;
     return false;
    }
   }
  }

  static dynamic Test6() // dynamiczny typ rezultatu
  {
   // return new Rekord(); // zmiana typu tworzonego tu obiektu moze spowodowac blad w p/w przykladach
   // return new Klasa();
   return new DynamicznaKlasa();
  }

 }
}
