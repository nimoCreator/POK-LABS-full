##########################################################
# Dowiazanie bibliotek CLR w skrypcie Pythona parsowanym #
# w aplikacji DLR - skrypt Py zewnetrznego modulu z GUI  #
##########################################################

# moduly elementow z biblioteki standardowej jezyka IronPython .NET:
import math
import sys
import clr # pomocniczy modul dla pelnego dostepu do srodowiska CLR platformy .NET

# dodatkowa konfiguracja dla interpretera IPy:
clr.AddReferenceByPartialName("System.Windows.Forms") # dowiazanie podzespolow CLR do uzycia w skrypcie Py (podzespol System jest dowiazany domyslnie)
clr.AddReferenceByPartialName("System.Drawing")

# elementy z przestrzeni nazw w bibliotece systemowej .NET Framework:
from System import Math
from System.Drawing import *
from System.Windows.Forms import *

# procedura wywolania zwrotnego do obslugi zdarzen w interakcji WinForms:
kroj = Font("Times New Roman", 15)
def wstaw_napis(nadawca, dane):
    a = dane.Location.X
    b = dane.Location.Y
    x = a*b*math.pi
    lblNapis = Label(Text = "py-sin: "+str(math.sin(x))+" | .NET-Sin: "+str(Math.Sin(x)))
    lblNapis.AutoSize = True
    lblNapis.Location = dane.Location
    lblNapis.Font = kroj
    nadawca.Controls.Add(lblNapis)

# utworzenie okna w interfejsie WinForms i jego konfiguracja:
okno = Form()
okno.Text = "WinForms in Python: "+sys.version
okno.ClientSize = Size(831, 512)
okno.Click += wstaw_napis

# wyswietlenie interfejsu GUI i uruchomienie interakcji z uzytkownikiem:
Application.Run(okno) # aplikacja WinForms zostanie wykonana w ramach procesu programu glownego
