/***********************************************************************************/
/* Najprostsza aplikacja skryptowa jako program EXE z uzyciem interpretera Python2 */     
/***********************************************************************************/

// dodatkowa konfiguracja dla kompilatora MSVC
#pragma warning(disable:4244)
#pragma warning(disable:4996 4005)
#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES
#ifdef UNICODE
# undef UNICODE
# define _MBCS
#endif

// pliki naglowkowe standardu C/C++ oraz interfejsu CPython API:
#include <cstdlib> 
#include <cstdio>
#include "Python.h"
using namespace std;

// glowna funkcja C/C++ dla skryptu Python:

static PyObject *_main_(PyObject *self)
{
 printf("witaj swiecie\n");
 Py_INCREF(Py_None);
 return Py_None;
}

// inicjacja modulu programowego we srodowisku Python:

static PyMethodDef _rejestr_[] = {
	{"Main", (PyCFunction)_main_, METH_NOARGS, "Main() doc string"},
	{NULL, NULL}
};

void _init_()
{
	Py_InitModule("Program", _rejestr_);
}

// glowna funkcja aplikacji skryptowej:

int main()
{
 Py_Initialize(); // zainicjowanie interpretera
 _init_(); // jawne wywolanie funkcji inicjujacej modul ze glowna funkcja skryptu
 PyRun_SimpleString( // interpretacja skryptu ze wywolaniem tej glownej funkcji
  "from Program import Main\n"
  "Main()\n"
 ); 
 Py_Finalize(); // zamkniecie interpretera
 
 return 0;
}
 