#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <ctime>
#include <cstdio>
#include <iostream>
#include "nransi.h" // biblioteka NRecip dla jezyka ANSI C/C++
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static PyObject *SortArray(PyObject *self, PyObject *args) // podstawowa metoda modulu
{ // test pelnej integracji procedury sortowania z biblioteki NR
 PyObject *list;
 int verbose = 0;
 if (!PyArg_ParseTuple(args, "O|i", &list, &verbose)) return NULL;

 int n = PyList_Size(list);
 if (verbose)
 cout << "n = " << n << endl;

 float *A = new float[n]; 
 for (int i=0; i<n; i++) {
  float x = 0.0;
  PyObject *item = PyList_GetItem(list, i);
  if (PyFloat_Check(item) || PyInt_Check(item)) {
   x = (float)PyFloat_AsDouble(item);
   if (verbose)
   cout << i << ") x = " << x << endl;
  } 
  A[i] = x;
 } 
 
 qcksrt(n,A-1); // procedura biblioteki NR z kodem algorytmu "Quick Sort" 

 list = PyList_New(n);
 for (int i=0; i<n; i++) {
  float y = A[i];
  if (verbose)
  cout << i << ") y = " << y << endl;
  PyObject *item = PyFloat_FromDouble((double)y);
  PyList_SetItem(list, i, item); 
 } 
 delete[] A;

 return Py_BuildValue("O", list);
}

extern "C" void nrerror(const char *str) // dolaczona do biblioteki NR funkcja uzytkownika do obslugi bledow
{
 static char buf[1024];
 sprintf(buf, "\n\n!!! NR-Error: %s !!!\n\n", str);
 Py_FatalError(buf);
}

static PyObject *RandArray(PyObject *self, PyObject *args) // pomocnicza metoda modulu
{ // uzycie procedury generatora liczb pseudolosowych z biblioteki NR
 int n;
 int verbose = 0;

 if (!PyArg_ParseTuple(args, "i|i", &n, &verbose)) return NULL;

 if (verbose)
 cout << "n = " << n << endl;

	int seed = time(NULL);
 PyObject *list = PyList_New(n);
 for (int i=0; i<n; i++) {
  float y = ran3(&seed);
  if (verbose)
  cout << i << ") y = " << y << endl;
  PyObject *item = PyFloat_FromDouble((double)y);
  PyList_SetItem(list, i, item); 
 } 

 return Py_BuildValue("O", list);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest01b_methods[] = {
	{"SortArray", (PyCFunction)SortArray, METH_VARARGS, "Call the 'qcksrt' routine from NR library"},
	{"RandArray", (PyCFunction)RandArray, METH_VARARGS, "Call the 'ran3' routine from NR library"},
	{NULL}
};

extern "C" void initpytest01b()
{
	Py_InitModule("pytest01b", pytest01b_methods);
}
