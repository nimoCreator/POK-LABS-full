#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <cstdio>
#include <iostream>
#include "nransi.h" // biblioteka NRecip dla jezyka ANSI C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

int main() // glowna funkcja programu
{ // test uzycia procedury sortowania z biblioteki NR
 int n;
 float A[100] = {0.0}; 
 
 cout << "n = "; cin >> n;
 cout << "podaj elementy tablicy:" << endl;
 for (int i=0; i<n; i++) {
  float x;
  cout << i << ") x = "; cin >> x;
  A[i] = x;
 } 
 
 qcksrt(n,A-1); // procedura biblioteki NR z kodem algorytmu "Quick Sort" 
 // uwaga: w bibliotece NR tablice sa indeksowane od 1, 
 // stad w wywolaniu procedury nalezy podac argument: A-1

 cout << "tablica posortowana:" << endl;
 for (int i=0; i<n; i++) {
  float x = A[i];
  cout << i << ") x = " << x << endl;
 } 

 return 0;
}

extern "C" void nrerror(const char *str) // dolaczona do biblioteki NR funkcja uzytkownika do obslugi bledow
{
 fprintf(stderr, "\n\n!!! NR-Error: %s !!!\n\n", str);
 abort();
}