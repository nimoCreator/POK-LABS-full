#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <cstdio>
#include <iostream>
#include <cmath>
#include "nransi.h" // biblioteka NRecip dla jezyka ANSI C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static int func_; // przekazywana do biblioteki NR funkcja uzytkownika do obliczenia wartosci danej funkcji
static float nrfunction(float x)
{
 float y = 0.0;
 switch (func_) {
  case 1: y = (float)sin(x); break;
  case 2: y = (float)cos(x); break;
  case 3: y = (float)exp(x); break;
  case 4: y = (float)sqrt(x); break;
  case 5: y = (float)log(x); break;
 } 
 return y;
}

int main() // glowna funkcja programu
{ // test uzycia procedury calkowania z biblioteki NR
 float a,b;
 
 cout << "podaj numer funkcji:" << endl;
 cout << "[1] sin" << endl;
 cout << "[2] cos" << endl;
 cout << "[3] exp" << endl;
 cout << "[4] sqrt" << endl;
 cout << "[5] log" << endl;
 cin >> func_;
 
 cout << "a = "; cin >> a;
 cout << "b = "; cin >> b;
 
 float I = qtrap(nrfunction,a,b); // procedura biblioteki NR z kodem metody trapezow 

 cout << "calka funkcji: " << I << endl;

 return 0;
}

extern "C" void nrerror(const char *str) // dolaczona do biblioteki NR funkcja uzytkownika do obslugi bledow
{
 fprintf(stderr, "\n\n!!! NR-Error: %s !!!\n\n", str);
 abort();
}