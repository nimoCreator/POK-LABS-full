#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <ctime>
#include <cstdio>
#include <iostream>
#include "ctests.h" // biblioteka wlasnych procedur do testowania kodow jezyka C/C++
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static PyObject *MatrDet(PyObject *self, PyObject *args) // podstawowa metoda modulu
{ // test pelnej integracji wlasnej procedury obliczania wyznacznikow
 PyObject *table;
 int verbose = 0;
 if (!PyArg_ParseTuple(args, "O|i", &table, &verbose)) return NULL;

 int n = PyList_Size(table);
 if (verbose)
 cout << "n = " << n << endl;

 static matrix A;
 for (int i=0; i<n; i++) {
  if (i>=MAXSIZ) continue;
  element a = 0.0;
  PyObject *row = PyList_GetItem(table, i);
  for (int j=0; j<n; j++) {
   if (j>=MAXSIZ) continue;
   if (PyList_Check(row)) {
    PyObject *item = PyList_GetItem(row, j);
    if (PyFloat_Check(item) || PyInt_Check(item)) {
     a = (element)PyFloat_AsDouble(item);
     if (verbose)
     cout << i << "," << j << ") a = " << a << endl;
    }
   } 
   A[i][j] = a;
  }  
 } 
 
 element d = lapdet(n,A);

 if (verbose)
 cout << "d = " << d << endl;

 return PyFloat_FromDouble((double)d);
}

extern "C" void cerror(const char *str) // dolaczona do biblioteki funkcja uzytkownika do obslugi bledow
{
 static char buf[1024];
 sprintf(buf, "\n\n!!! CTest-Error: %s !!!\n\n", str);
 Py_FatalError(buf);
}

static PyObject *RandMatr(PyObject *self, PyObject *args) // pomocnicza metoda modulu
{ // uzycie funkcji generatora liczb pseudolosowych z biblioteki standardowej
 int n;
 int verbose = 0;

 if (!PyArg_ParseTuple(args, "i|i", &n, &verbose)) return NULL;

 if (verbose)
 cout << "n = " << n << endl;

	int seed = time(NULL);
 PyObject *table = PyList_New(n);
 for (int i=0; i<n; i++) {
  PyObject *row = PyList_New(n);
  for (int j=0; j<n; j++) {
   element a = 10.0*(element)rand()/RAND_MAX;
   if (verbose)
   cout << i << "," << j << ") a = " << a << endl;
   PyObject *item = PyFloat_FromDouble((double)a);
   PyList_SetItem(row, j, item); 
  } 
  PyList_SetItem(table, i, row); 
 } 

 return Py_BuildValue("O", table);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest03b_methods[] = {
	{"MatrDet", (PyCFunction)MatrDet, METH_VARARGS, "Call the 'lapdet' routine"},
	{"RandMatr", (PyCFunction)RandMatr, METH_VARARGS, "Call the 'rand' routine from std library"},
	{NULL}
};

extern "C" void initpytest03b()
{
	Py_InitModule("pytest03b", pytest03b_methods);
}
