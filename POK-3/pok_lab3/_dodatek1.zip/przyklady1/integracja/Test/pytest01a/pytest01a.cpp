#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <cstdio>
#include <iostream>
#include "nransi.h" // biblioteka NRecip dla jezyka ANSI C/C++
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static PyObject *main_code_(PyObject *self) // glowna metoda modulu
{ // test uzycia procedury sortowania z biblioteki NR
 int n;
 float A[100] = {0.0}; 

 cout << "n = "; cin >> n;
 cout << "podaj elementy tablicy:" << endl;
 for (int i=0; i<n; i++) {
  float x;
  cout << i << ") x = "; cin >> x;
  A[i] = x;
 } 
 
 qcksrt(n,A-1); // procedura biblioteki NR z kodem algorytmu "Quick Sort" 

 cout << "tablica posortowana:" << endl;
 for (int i=0; i<n; i++) {
  float x = A[i];
  cout << i << ") x = " << x << endl;
 } 

	Py_INCREF(Py_None);
	return Py_None;
}

extern "C" void nrerror(const char *str) // dolaczona do biblioteki NR funkcja uzytkownika do obslugi bledow
{
 static char buf[1024];
 sprintf(buf, "\n\n!!! NR-Error: %s !!!\n\n", str);
 Py_FatalError(buf);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest01a_methods[] = {
	{"Main", (PyCFunction)main_code_, METH_NOARGS, "Simple QuickSort Test based on a NR library routine"},
	{NULL}
};

extern "C" void initpytest01a()
{
	Py_InitModule("pytest01a", pytest01a_methods);
}
