#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <cstdio>
#include <iostream>
#include <iomanip>
#include "ctests.h" // biblioteka wlasnych procedur do testowania kodow jezyka C/C++
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static PyObject *main_code_(PyObject *self) // glowna metoda modulu
{ // test uzycia wlasnej procedury obliczania macierzy odwrotnej
 static matrix X1={ // macierz osobliwa
		   {1, 1, 1},
		   {2, 2, 2},
		   {3, 3, 3}
		  };

 static matrix X2={ // macierz diagonalna
		   {1, 0, 0},
		   {0, 2, 0},
		   {0, 0, 3}
		  };
		  
	static matrix Y1,Y2;

 cout << boolalpha << fixed << showpos << setw(7) << setprecision(3);

 boolean r1 = gauinv(3,X1,Y1);
 boolean r2 = gauinv(3,X2,Y2);

 cout << "gauinv(X1,Y1) = " << r1 << ", Y1 = {" << endl;
 for (int i=0; i<3; i++) {
  for (int j=0; j<3; j++) cout << Y1[i][j] << "  ";
  cout << endl;
 } 
 cout << "}" << endl;
 cout << endl;
 cout << "gauinv(X2,Y2) = " << r2 << ", Y2 = {" << endl;
 for (int i=0; i<3; i++) {
  for (int j=0; j<3; j++) cout << Y2[i][j] << "  ";
  cout << endl;
 } 
 cout << "}" << endl;
 cout << endl;
 
 static matrix X3,Y3;
 for (;;) {
  int n;
  cout << "n="; cin >> n;
  if (n<0) break;
  for (int i=0; i<n; i++)
  for (int j=0; j<n; j++) {
   if (i>=MAXSIZ || j>=MAXSIZ) continue;
   X3[i][j]=10.0*(element)rand()/RAND_MAX; 
  }
  boolean r3 = gauinv(n,X3,Y3);
  cout << "gauinv(X3,Y3) = " << r3 << ", Y3 = {" << endl;
  for (int i=0; i<n; i++) {
   for (int j=0; j<n; j++) cout << Y3[i][j] << "  ";
   cout << endl;
  } 
  cout << "}" << endl;
  cout << endl;
 }

	Py_INCREF(Py_None);
	return Py_None;
}

extern "C" void cerror(const char *str) // dolaczona do biblioteki funkcja uzytkownika do obslugi bledow
{
 static char buf[1024];
 sprintf(buf, "\n\n!!! CTest-Error: %s !!!\n\n", str);
 Py_FatalError(buf);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest04a_methods[] = {
	{"Main", (PyCFunction)main_code_, METH_NOARGS, "Simple Matrix Inverse Test"},
	{NULL}
};

extern "C" void initpytest04a()
{
	Py_InitModule("pytest04a", pytest04a_methods);
}
