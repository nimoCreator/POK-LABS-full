#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <cstdio>
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;

static PyObject *main_code_(PyObject *self) // glowna metoda modulu
{ // test uzycia operacji we/wy z biblioteki std jezyka C
	
	printf("Witaj swiecie\n"); // drukowanie napisu bezposrednio w oknie konsoli srodowiska Python
	
	Py_INCREF(Py_None);
	return Py_None;
}

// zarejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest00_methods[] = {
	{"Main", (PyCFunction)main_code_, METH_NOARGS, "C I/O Library Test"},
	{NULL}
};

extern "C" void initpytest00()
{
	Py_InitModule("pytest00", pytest00_methods);
}
