#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <ctime>
#include <cstdio>
#include <iostream>
#include "ctests.h" // biblioteka wlasnych procedur do testowania kodow jezyka C/C++
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static PyObject *MatrInv(PyObject *self, PyObject *args) // podstawowa metoda modulu
{ // test pelnej integracji wlasnej procedury obliczania macierzy odwrotnej
 PyObject *table1;
 PyObject *table2;
 int verbose = 0;
 if (!PyArg_ParseTuple(args, "OO|i", &table1, &table2, &verbose)) return NULL;

 int n = PyList_Size(table1);
 if (verbose)
 cout << "n = " << n << endl;

 static matrix X;
 for (int i=0; i<n; i++) {
  if (i>=MAXSIZ) continue;
  element x = 0.0;
  PyObject *row = PyList_GetItem(table1, i);
  for (int j=0; j<n; j++) {
   if (j>=MAXSIZ) continue;
   if (PyList_Check(row)) {
    PyObject *item = PyList_GetItem(row, j);
    if (PyFloat_Check(item) || PyInt_Check(item)) {
     x = (element)PyFloat_AsDouble(item);
     if (verbose)
     cout << i << "," << j << ") x = " << x << endl;
    }
   } 
   X[i][j] = x;
  }  
 } 
 
 static matrix Y;
 boolean r = gauinv(n,X,Y);

 if (verbose)
 cout << "r = " << r << endl;

 for (int i=0; i<n; i++) {
  PyObject *row = PyList_New(n);
  for (int j=0; j<n; j++) {
   element y = Y[i][j];
   if (verbose)
   cout << i << "," << j << ") y = " << y << endl;
   PyObject *item = PyFloat_FromDouble((double)y);
   PyList_SetItem(row, j, item); 
  } 
  PyList_Append(table2, row); 
 } 

 return PyInt_FromLong((long)r);
}

extern "C" void cerror(const char *str) // dolaczona do biblioteki funkcja uzytkownika do obslugi bledow
{
 static char buf[1024];
 sprintf(buf, "\n\n!!! CTest-Error: %s !!!\n\n", str);
 Py_FatalError(buf);
}

static PyObject *RandMatr(PyObject *self, PyObject *args) // pomocnicza metoda modulu
{ // uzycie funkcji generatora liczb pseudolosowych z biblioteki standardowej
 int n;
 int verbose = 0;

 if (!PyArg_ParseTuple(args, "i|i", &n, &verbose)) return NULL;

 if (verbose)
 cout << "n = " << n << endl;

	int seed = time(NULL);
 PyObject *table = PyList_New(n);
 for (int i=0; i<n; i++) {
  PyObject *row = PyList_New(n);
  for (int j=0; j<n; j++) {
   element a = 10.0*(element)rand()/RAND_MAX;
   if (verbose)
   cout << i << "," << j << ") a = " << a << endl;
   PyObject *item = PyFloat_FromDouble((double)a);
   PyList_SetItem(row, j, item); 
  } 
  PyList_SetItem(table, i, row); 
 } 

 return Py_BuildValue("O", table);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest04b_methods[] = {
	{"MatrInv", (PyCFunction)MatrInv, METH_VARARGS, "Call the 'gauinv' routine"},
	{"RandMatr", (PyCFunction)RandMatr, METH_VARARGS, "Call the 'rand' routine from std library"},
	{NULL}
};

extern "C" void initpytest04b()
{
	Py_InitModule("pytest04b", pytest04b_methods);
}
