#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <cstdio>
#include <iostream>
#include "nransi.h" // biblioteka NRecip dla jezyka ANSI C/C++
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static PyObject *func_; // przekazywana do biblioteki NR funkcja uzytkownika do obliczenia wartosci danej funkcji
static float nrfunction(float x)
{
 float y = 0.0;
 PyObject *item = PyObject_CallFunction(func_, "f", x);
 if (item!=NULL && (PyFloat_Check(item) || PyInt_Check(item)))
 y = (float)PyFloat_AsDouble(item);
 Py_DECREF(item);
 return y;
}

static PyObject *IntegFunc(PyObject *self, PyObject *args) // podstawowa metoda modulu
{ // test pelnej integracji procedury calkowania z biblioteki NR
 float a,b;
 int verbose = 0;
 if (!PyArg_ParseTuple(args, "Off|i", &func_, &a, &b, &verbose)) return NULL;
 if (!PyCallable_Check(func_)) return NULL;
  
 if (verbose) {
  cout << "a = " << a << endl;
  cout << "b = " << b << endl;
  float ya = nrfunction(a);
  float yb = nrfunction(b);
  cout << "f(a) = " << ya << endl;
  cout << "f(b) = " << yb << endl;
 } 

 float I = qtrap(nrfunction,a,b); // procedura biblioteki NR z kodem metody trapezow 
 
 if (verbose)
 cout << "I = " << I << endl;

 return PyFloat_FromDouble((double)I);
}

extern "C" void nrerror(const char *str) // dolaczona do biblioteki NR funkcja uzytkownika do obslugi bledow
{
 static char buf[1024];
 sprintf(buf, "\n\n!!! NR-Error: %s !!!\n\n", str);
 Py_FatalError(buf);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest02b_methods[] = {
	{"IntegFunc", (PyCFunction)IntegFunc, METH_VARARGS, "Call the 'qtrap' routine from NR library"},
	{NULL}
};

extern "C" void initpytest02b()
{
	Py_InitModule("pytest02b", pytest02b_methods);
}
