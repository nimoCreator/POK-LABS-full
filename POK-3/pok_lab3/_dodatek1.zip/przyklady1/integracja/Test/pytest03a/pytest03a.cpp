#include <cstdlib> // biblioteka standardowa jezyka C/C++
#include <cstdio>
#include <iostream>
#include <iomanip>
#include "ctests.h" // biblioteka wlasnych procedur do testowania kodow jezyka C/C++
#include "Python.h" // API srodowiska Python dla jezyka C/C++
using namespace std;
#pragma warning(disable:4996) // wylaczenie ostrzezenia dot. funkcji starego standardu, funkcje te sa zastapione przez nowe

static PyObject *main_code_(PyObject *self) // glowna metoda modulu
{ // test uzycia wlasnych procedur obliczania wyznacznikow
 static matrix A1={ // det = 0.0
		   {1, 1, 1},
		   {2, 2, 2},
		   {3, 3, 3}
		  };

 static matrix A2={ // det = 6.0
		   {1, 0, 0},
		   {0, 2, 0},
		   {0, 0, 3}
		  };

 static matrix A3={ // Excel: det = 7658.888201 dla elementow typu double
		   {0.10,  1.03, -0.78,  3.56,  -9.87},
		   {2.11, -1.93,  2.58, -5.86,  19.97},
		   {5.16, -8.33, -6.88, -4.26,  -9.77},
		   {0.22,  3.53, -9.70,  2.56,  -1.87},
		   {3.96, -1.23, -9.83, -2.56,  -4.27},
		  };

 cout << setprecision(10);

 cout << "lapdet A1 = " << lapdet(3,A1) << endl;
 cout << "defdet A1 = " << defdet(3,A1) << endl;
 cout << "lapdet A2 = " << lapdet(3,A2) << endl;
 cout << "defdet A2 = " << defdet(3,A2) << endl;
 cout << "lapdet A3 = " << lapdet(5,A3) << endl;
 cout << "defdet A3 = " << defdet(5,A3) << endl;
 cout << endl;
 
 static matrix A4;
 for (;;) {
  int n;
  cout << "n="; cin >> n;
  if (n<0) break;
  for (int i=0; i<n; i++)
  for (int j=0; j<n; j++) {
   if (i>=MAXSIZ || j>=MAXSIZ) continue;
   A4[i][j]=10.0*(element)rand()/RAND_MAX; 
  }
  cout << "lapdet A4 = " << lapdet(n,A4) << endl;
  cout << "defdet A4 = " << defdet(n,A4) << endl;
  cout << endl;
 }

	Py_INCREF(Py_None);
	return Py_None;
}

extern "C" void cerror(const char *str) // dolaczona do biblioteki funkcja uzytkownika do obslugi bledow
{
 static char buf[1024];
 sprintf(buf, "\n\n!!! CTest-Error: %s !!!\n\n", str);
 Py_FatalError(buf);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef pytest03a_methods[] = {
	{"Main", (PyCFunction)main_code_, METH_NOARGS, "Simple Matrix Determinant Test"},
	{NULL}
};

extern "C" void initpytest03a()
{
	Py_InitModule("pytest03a", pytest03a_methods);
}
