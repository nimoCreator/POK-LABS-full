@echo off
rem Plik startowy do wykonywania natywnych programow testowych z kodem w jezyku C
cd Bin
cmd.exe