@echo off
rem Plik startowy do uzywania modulow testowych z kodem jezyka C w srodowisku Python
cd Bin
cmd.exe /K python.exe