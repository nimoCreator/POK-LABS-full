/*
 * Implementacja algorytmow ogolnych 
 * i metod numerycznych przeznaczona
 * do testowania kodow jezyka C/C++
 */

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MAXSIZ 100 /* maksymalny rozmiar (rzad) macierzy */
typedef double element; /* typ elementow macierzy */
typedef element matrix[MAXSIZ][MAXSIZ]; /* typ macierzy */
#ifdef __cplusplus
typedef bool boolean; /* typ logiczny dla jezyka C++ */
#define False false
#define True true
#else
typedef int boolean; /* typ logiczny dla jezyka C */
#define False 0
#define True 1
#endif

element lapdet(int s,matrix A); /* metoda obliczania wyznacznikow oparta na rozwinieciu Laplace'a */
element defdet(int s,matrix A); /* metoda obliczania wyznacznikow oparta na bezposredniej definicji wyznacznika */
boolean gauinv(int n,matrix X,matrix Y);  /* metoda obliczania macierzy odwrotnej oparta na eliminacji Gaussa */

void cerror(const char *str); /* deklaracja funkcji do obslugi bledow w kodzie aplikacyjnym */

#ifdef __cplusplus
}
#endif
