/*
 * Procedury obliczania wyznacznikow 
 * dowolnych macierzy kwadratowych rzedu n 
 * z implementacja standardowych metod
 */

#include "ctests.h"
#include <stdlib.h>

/* Metoda oparta na rozwiniecia Laplace'a
 *
 * parametry:
 *   n - rzad macierzy, maksymlnie MAXSIZ
 *   A - wejsciowa macierz n x n
 * rezultat: wartosc wyznacznika macierzy wejsciowej
 */
element lapdet(int n,matrix A)
{
 static boolean xrow[MAXSIZ], xcol[MAXSIZ];
 int i,j;
 int k=0;
 element d=0.0;

 if (n>MAXSIZ) cerror("Matrix size is too big");

 for (i=0; i<n; i++) 
 if (!xrow[i]) { /* wiersz i-ty jest wlaczony */
  int l=0;
  k++;
  xrow[i]=True; /* wylacz i-ty wiersz */

  for (j=0; j<n; j++) 
  if (!xcol[j]) { /* kolumna j-ta jest wlaczona */
   l++;
   xcol[j]=True; /* wylacz j-ta kolumne, stad efektywnie mamy minor rzedu n-1 */
   d += A[i][j] * ( (k+l)%2==0 ? +1.0 : -1.0 ) * lapdet(n,A) ; /* wyraz rozw. Laplace'a */
   xcol[j]=False; /* wlacz j-ta kolumne */
  }

  xrow[i]=False; /* wlacz i-ty wiersz */
  break; /* uwzglednij jedynie pierwszy wiersz danej macierzy */
 }

 return k>0 ? d : 1.0; /* wyznacznik macierzy rzedu zerowego z def. jest rowny 1.0 */
}

/* Metoda oparta na bezposredniej definicji
 *
 * parametry:
 *   n - rzad macierzy, maksymlnie MAXSIZ
 *   A - wejsciowa macierz n x n
 * rezultat: wartosc wyznacznika macierzy wejsciowej
 *
 * uwaga: w stosunku do lapdet dziala 
 * o ok. 35% dluzej, gdyz zawiera wiecej 
 * mnozen elementow
 */
element defdet(int n,matrix A)
{
 struct { 
  int val;
  boolean off;
 } p[MAXSIZ];
 int i,j,l;
 int k=0;
 element d=0.0;
 
 if (n>MAXSIZ) cerror("Matrix size is too big");

 for (i=0; i<n; i++) p[i].val=-1,  p[i].off=False;

 for (;;) { /* suma po permutacjach n liczb */
  int ninv=0;

/* generator permutacji n liczb: */
  while (k<n) {
   int v=p[k].val;
   if (v>=0) p[v].off=False;
   v++;
   while (v<n)
   if (p[v].off) v++; else break;
   if (v<n) p[k].val=v, p[v].off=True, k++;
   else {
	   p[k].val=-1;
	   if (k<=0) break;
	   k--;
   }
  }
  if (--k<0) break; /* koniec zbioru wszystkich permutacji */

/* obliczenie liczby inwersji: */
  for (i=0; i<n; i++)
  for (j=i+1; j<n; j++)
  if (p[i].val>p[j].val) ninv++;

/* dodanie wyrazu z definicji wyznacznika: */
  {
   element w=1.0;
   for (l=0; l<n; l++) w*=A[p[l].val][l];
   d += (ninv%2==0 ? +1.0 : -1.0) * w;
  }
 }

 return n>0 ? d : 1.0; /* wyznacznik macierzy rzedu zerowego z def. jest rowny 1.0 */
}
