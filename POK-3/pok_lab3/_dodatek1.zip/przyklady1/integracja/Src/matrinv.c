/*
 * Procedury obliczania macierzy odwrotnej 
 * dowolnych macierzy kwadratowych rzedu n 
 * z implementacja standardowych metod
 */

#include "ctests.h"
#include <stdlib.h>

/* Metoda oparta na eliminacji Gaussa
 *
 * parametry:
 *   n - rzad macierzy, maksymlnie MAXSIZ
 *   X - macierz n x n wejsciowa, uwaga: po zakonczeniu obliczen jej zawartosc jest nieokreslona
 *   Y - macierz n x n odwrotna do macierzy wejsciowej
 */
boolean gauinv(int n,matrix X,matrix Y)
{
 const element eps=1e-12; // eps<1.0
 int i,j,ia,ib,ic;
 int in=n-1;
 for (i=0; i<n; i++) 
 for (j=0; j<n; j++) 
 Y[i][j] = i==j ? 1.0 : 0.0;
 for (ia=0; ia<in; ia++) {
  element xmax=0.0;
  int io=ia;
  for (ib=ia; ib<n; ib++){
   element xval=X[ib][ia];
   if (xval<0.0) xval=-xval;
   if (xmax<xval){
    xmax=xval;
    io=ib;
   }
  }
  if (xmax<eps) return False;
  if (io!=ia) {
   for (ib=ia; ib<n; ib++) {
    element *Xiaib=&X[ia][ib];
    element *Xioib=&X[io][ib];
    element xval=*Xiaib;
    *Xiaib=*Xioib;
    *Xioib=xval;
   }
   for (ib=0; ib<n; ib++) {
    element *Yiaib=&Y[ia][ib];
    element *Yioib=&Y[io][ib];
    element yval=*Yiaib;
    *Yiaib=*Yioib;
    *Yioib=yval;
   }
  }
  {
   element *Xiaia=&X[ia][ia];
   for (ib=ia+1; ib<n; ib++) {
    element *Xibia=&X[ib][ia];
    for (ic=ia+1; ic<n; ic++)
    X[ib][ic]-=X[ia][ic] * *Xibia / *Xiaia;
    for (ic=0; ic<n; ic++)
    Y[ib][ic]-=Y[ia][ic] * *Xibia / *Xiaia;
   }
  }
 }
 {
  element *Xinin=&X[in][in];
  for (ib=0; ib<n; ib++) {
   Y[in][ib]/=*Xinin;
   for (ia=in-1; ia>=0; ia--) {
    element *Yiaib=&Y[ia][ib];
    for (ic=ia+1; ic<n; ic++)
    *Yiaib-=X[ia][ic]*Y[ic][ib];
    *Yiaib/=X[ia][ia];
   }
  }
 }
 return True;
}
