INTEGRACJA OPROGRAMOWANIA C/C++ W �RODOWISKU PYTHON2
====================================================
|Praca magisterska
|Dawid WITCZAK
|Katowice, 2011 

W katalogu 'Bin' znajduja sie natywne programy "*.exe" jezyka C testujace 
dzialanie wybranych algorytmow ogolnych oraz metod numerycznych w oparciu
o wlasna implementacje oraz z uzyciem procedur wybranej biblioteki numerycznej
"Numerical Recipes in C". Katalog zawiera rowniez moduly pythona "*.dll" 
do testowania integracji p/w algorytmow i metod ze srodowiskiem Python. 
Projekty wszystkich testow wystepuja w katalogu 'Test' i zostaly utworzone 
w srodowisku Visual Studio 2005 z uzyciem jezyka Visual C++ 8. W projektach 
dolaczono interfejs Python/C API dla srodowiska w wersji 2.2.3, zainstalowanego 
w systemie operacyjnym Windows. Wymagana jest biblioteka 'python22.lib' 
dla trybu 'Release' projektow oraz biblioteka 'python22_d.lib' dla trybu 'Debug'.
Pobranie pakietu instalacyjnego srodowiska mozliwe jest poprzez odnosnik 'Download Python'. 
Kody wlasne algorytmow ogolnych wspolne dla p/w projektow testowych zamieszczone sa 
w postaci osobnych plikow "*.c" w katalogu 'Src' i sa wprost dolaczone do projektow. 
Podobnie procedury metod numerycznych z wybranej biblioteki podano w postaci plikow
w podkatalogu 'Src/NR'. Pobranie dokumentacji PDF zawierajacej procedury biblioteki 
i ich opis mozliwe jest poprzez odnosnik 'Download Numerical Recipes in C' w tym podkatalogu. 

Uzycie modulow testowych wymaga uruchomienia interpretera jezyka Python 
w biezacym katalogu 'Test', co wykonuje sie poprzez polecenia w pliku 
wsadowym 'startpy.bat'. Natomiast uruchomienie programow testowych
wymaga jedynie linii polecen konsoli, co daje plik wsadowy startc.bat.

Ponizej podano opis zawartosci oraz uzycia poszczegolnych natywnych programow
testowych jezyka C oraz modulow testowych dla srodowiska Python.

test00
------

Modul zawiera metode o nazwie 'Main' z przykladowym kodem ilustrujacym 
tworzenie interfejsu uzytkownika modulu w oparciu o biblioteke operacji 
we/wy jezyka C. Wywolanie metody w linii polecen srodowiska Python jest 
nastepujace:

>>> import pytest00
>>> pytest00.Main()

test01
------

Program zawiera kod z przykladem uzycia procedury 'qcksrt' z biblioteki NRecip
do sortowania tablicy liczb rzeczywistych w oparciu o algorytm QuickSort. Nalezy 
podac liczbe elementow tablicy oraz ich wartosci. Uruchomienie programu w linii 
polecen konsoli systemowej jest nastepujace:

> ctest01.exe

Modul w wersji 'a' zawiera metode o nazwie 'Main' z kopia kodu p/w programu. 
Wywolanie metody w linii polecen srodowiska Python jest nastepujace:

>>> import pytest01a
>>> pytest01a.Main()

Modul w wersji 'b' zawiera metode o nazwie 'SortArray' o pelnej integracji z 
srodowiskiem Python. Dodatkowo modul zawiera pomocnicza metode 'RandArray'
do generowania pseudolosowej tablicy. Uzycie metod w skrypcie jezyka Python 
ilustruje nastepujacy przyklad:

from pytest01b import *
A = RandArray(100)  # argumenty: liczba elementow tablicy, flaga wyswietlania komunikatow (domyslnie: False) ; rezultat: pseudolosowa tablica elementow
B = SortArray(A)    # argumenty: dowolna tablica elementow, flaga wyswietlania komunikatow (domyslnie: False) ; rezultat: posortowana tablica elementow
print B

test02
------

Program zawiera kod z przykladem uzycia procedury 'trapzd' z biblioteki NRecip
do calkowania funkcji jednej zmiennej metoda trapezow. Nalezy podac poczatek i
koniec przedzialu calkowania. Uruchomienie programu w linii polecen konsoli 
systemowej jest nastepujace:

> ctest02.exe

Modul w wersji 'a' zawiera metode o nazwie 'Main' z kopia kodu p/w programu. 
Wywolanie metody w linii polecen srodowiska Python jest nastepujace:

>>> import pytest02a
>>> pytest02a.Main()

Modul w wersji 'b' zawiera metode o nazwie 'IntegFunc' o pelnej integracji z 
srodowiskiem Python. Uzycie metody w skrypcie jezyka Python ilustruje nastepujacy 
przyklad:

from pytest02b import *
import math
I = IntegFunc(math.exp, 1, 2)  # argumenty: calkowana funkcja, poczatek i koniec przedzialu, flaga wyswietlania komunikatow (domyslnie: False) ; rezultat: wartosc calki
print I

test03
------

Program zawiera kod z przykladem uzycia procedur 'lapdet' i 'defdet' z wlasnej biblioteki
przeznaczonych do obliczania wyznacznika macierzy kwadratowej liczb rzeczywistych stopnia n 
w oparciu o metody standardowe. Nalezy podac liczbe stopien macierzy oraz wartosci jej elementow. 
Uruchomienie programu w linii polecen konsoli systemowej jest nastepujace:

> ctest03.exe

Modul w wersji 'a' zawiera metode o nazwie 'Main' z kopia kodu p/w programu. 
Wywolanie metody w linii polecen srodowiska Python jest nastepujace:

>>> import pytest03a
>>> pytest03a.Main()

Modul w wersji 'b' zawiera metode o nazwie 'MatrDet' o pelnej integracji z 
srodowiskiem Python. Metodzie zostala uzyta procedura 'lapdet'. Dodatkowo 
modul zawiera pomocnicza metode 'RandMatr' do generowania pseudolosowej macierzy. 
Uzycie metod w skrypcie jezyka Python ilustruje nastepujacy przyklad:

from pytest03b import *
A = RandMatr(5)  # argumenty: stopien macierzy, flaga wyswietlania komunikatow (domyslnie: False) ; rezultat: pseudolosowa macierz elementow
d = MatrDet(A)   # argumenty: dowolna macierz elementow, flaga wyswietlania komunikatow (domyslnie: False) ; rezultat: wyznacznik macierzy
print d

test04
------

Program zawiera kod z przykladem uzycia procedur 'gauinv' z wlasnej biblioteki
do obliczania odwrotnej macierzy kwadratowej liczb rzeczywistych stopnia n 
w oparciu o metody standardowe. Nalezy podac liczbe stopien macierzy oraz wartosci 
jej elementow. Uruchomienie programu w linii polecen konsoli systemowej jest nastepujace:

> ctest04.exe

Modul w wersji 'a' zawiera metode o nazwie 'Main' z kopia kodu p/w programu. 
Wywolanie metody w linii polecen srodowiska Python jest nastepujace:

>>> import pytest04a
>>> pytest04a.Main()

Modul w wersji 'b' zawiera metode o nazwie 'MatrDet' o pelnej integracji z 
srodowiskiem Python. Dodatkowo modul zawiera pomocnicza metode 'RandMatr' 
do generowania pseudolosowej macierzy. Uzycie metod w skrypcie jezyka Python 
ilustruje nastepujacy przyklad:

from pytest04b import *
X = RandMatr(5)  # argumenty: stopien macierzy, flaga wyswietlania komunikatow (domyslnie: False) ; rezultat: pseudolosowa macierz elementow
Y = []
r = MatrInv(X,Y) # argumenty: wejsciowa i wyjsciowa macierz elementow, flaga wyswietlania komunikatow (domyslnie: False) ; rezultat: sukces operacji
print r
print Y

