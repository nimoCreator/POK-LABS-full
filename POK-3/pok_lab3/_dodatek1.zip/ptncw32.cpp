/**********************************************************************/
/* Najprostsza skryptowa aplikacja C++ we CPython3 API jako modul DLL */     
/**********************************************************************/

// dodatkowa konfiguracja dla kompilatora MSVC
#pragma warning(disable:4244)
#pragma warning(disable:4996 4005)
#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES
#ifdef UNICODE
# undef UNICODE
# define _MBCS
#endif

// pliki naglowkowe standardu jezyka C/C++ oraz interfejsu API srodowiska Python dla jezyka C/C++:
#include <cstdlib>
#include <cstdio>
#include "Python.h"
using namespace std;

// glowna funkcja publiczna modulu:

static PyObject *_main_(PyObject *self) // parametr self wskazuje na obiekt tej funkcji lub tego modulu
{
 printf("Witaj swiecie\n"); // mozna tu korzystac ze biblioteki std

 Py_INCREF(Py_None); // powrot ze funkcji modulu do skryptu ze obiektem braku rezultatu
 return Py_None;
}

// zarejestrowanie listy metod modulu:

static PyMethodDef _rejestr_[] = {
    {"Main", (PyCFunction)_main_, METH_NOARGS, "Main() doc string"},
    {NULL, NULL}
};

// zapamietanie parametrow modulu:
//
// jest to rekord zawierajacy naglowkowe parametry 
// charakteryzujace modul, niezbedne dla srodowiska 
// skryptowego pythona
//
static PyModuleDef _rekord_ = {
    PyModuleDef_HEAD_INIT,
    "ptntest1",              // nazwa glowna modulu DLL jako pliku *.pyd (ptntest1.pyd)
    "ptntest1 doc string",   // lancuch z dokumentacja modulu
    -1,                      // rozmiar dynamicznego stanu interpretera dla modulu, -1 dla stanu w pamieci statycznej
    _rejestr_
};

// funkcja inicjujaca modul z punktem wejscia do modulu:
//
// jest to specjalna funkcja eksportowana ze modulu na zewnatrz
// jako funkcja jezyka C, eksportowanie odbywa sie jedynie poprzez
// specyfikator __declspec(dllexport) ukryty we PyMODINIT_FUNC,
// stad zgodnie ze wymaganiami srodowiska python nazwa p/n funkcji 
// bedacej punktem wejscia srodowiska do modulu musi miec postac: PyInit_MODULE, 
// gdzie 'MODULE' to nazwa glowna utworzonego w projekcie modulu binarnego DLL 
//
PyMODINIT_FUNC PyInit_ptntest1(void)
{
    return PyModule_Create(&_rekord_);
}   