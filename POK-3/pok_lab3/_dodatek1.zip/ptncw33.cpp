/***********************************************************************************/
/* Najprostsza aplikacja skryptowa jako program EXE z uzyciem interpretera Python3 */     
/***********************************************************************************/

// dodatkowa konfiguracja dla kompilatora MSVC
#pragma warning(disable:4244)
#pragma warning(disable:4996 4005)
#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES
#ifdef UNICODE
# undef UNICODE
# define _MBCS
#endif

// pliki naglowkowe standardu C/C++ oraz interfejsu CPython API:
#include <cstdlib> 
#include <cstdio>
#include "Python.h"
using namespace std;

// glowna funkcja skryptu Python:

static PyObject *_main_(PyObject *self)
{
 printf("witaj swiecie\n");
 Py_INCREF(Py_None);
 return Py_None;
}

// inicjacja modulu programowego we srodowisku:

static PyMethodDef _rejestr_[] = {
    {"Main", (PyCFunction)_main_, METH_NOARGS, "Main() doc string"},
	{NULL, NULL}
};

static PyModuleDef _rekord_ = {
    PyModuleDef_HEAD_INIT, "Program", "Program doc string", -1, _rejestr_
};

extern "C" PyObject *_init_(void)
{
    return PyModule_Create(&_rekord_);
}

// glowna funkcja aplikacji skryptowej:

int main()
{
 PyImport_AppendInittab("Program", _init_); // wskazanie funkcji inicjujacej modul programowy z glowna funkcje skryptu
 Py_Initialize(); // zainicjowanie interpretera z niejawnym wywolanie p/w funkcji inicjujacej w punkcie p/n importu modulu 
 PyRun_SimpleString( // interpretacja skryptu z wywolaniem glownej funkcji skryptu
  "from Program import Main\n"
  "Main()\n"
 ); 
 Py_Finalize(); // zamkniecie interpretera
 
 return 0;
}
 