set PYTHONPATH=.
cd Bin
@echo off
echo .
echo . Run python interpreter or application...
echo .
start /B