/**********************************************************************/
/* Najprostsza skryptowa aplikacja C++ we CPython2 API jako modul DLL */     
/**********************************************************************/

// dodatkowa konfiguracja dla kompilatora MSVC
#pragma warning(disable:4244)
#pragma warning(disable:4996 4005)
#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES
#ifdef UNICODE
# undef UNICODE
# define _MBCS
#endif
#ifndef PY_MODULE_
# define PY_MODULE_ "test"
#endif

// pliki naglowkowe standardu jezyka C/C++ oraz interfejsu API srodowiska Python dla jezyka C/C++:
#include <cstdlib>
#include <cstdio>
#include "Python.h" 
using namespace std;

// glowna funkcja publiczna modulu:
//
// jest to zwykla funkcja statyczna jezyka C/C++ a jej nazwa 
// moze byc dowolna, funkcja ta moze byc wywolana ze skryptu
// pythona ale bez argumentow i rezultatu w punkcie wywolania
//
static PyObject *_main_(PyObject *self) // parametr self wskazuje na obiekt tej funkcji lub tego modulu
{                                       // brakujacy parametr args wskazuje na obiekt listy argumentow
 printf("Witaj swiecie\n"); // mozna tu korzystac ze biblioteki std

 Py_INCREF(Py_None); // powrot ze funkcji modulu do skryptu ze obiektem braku rezultatu
 return Py_None;
}

// zarejestrowanie listy metod modulu:
//
// jest to rejestr wszystkich p/w publicznych funkcji 
// nalezacych do modulu i dostepnych w srodowisku 
// skryptowym pythona poprzez podana p/n nazwe, wskaznik
// do p/w kodu funkcji, tryb wywolania bez args lub ze
// zmienna lista args oraz ze dodatkowa dokumentacja
// 
// uwaga: Dla trybu METH_NOARGS wymagna jest konwersja (PyCFunction) 
//
static PyMethodDef _rejestr_[] = {
	{"Main", (PyCFunction)_main_, METH_NOARGS, "Main() doc string"},
	{NULL, NULL} // wymagany koniec rejstru
};

// funkcja inicjujaca modul z punktem wejscia do modulu:
//
// jest to specjalna funkcja eksportowana ze modulu na zewnatrz
// jako funkcja jezyka C, eksportowanie moze odbywac sie poprzez
// opcje linkera /export lub specyfikator __declspec(dllexport)
// lub poprzez plik *.def w sekcji EXPORTS, funkcja ta jest punktem 
// wejscia srodowiska python do modulu i stad jest przez srodowisko
// wywolywana w punkcie importu modulu przez interpretowany skrypt
//
// uwaga: zgodnie ze wymaganiami srodowiska python nazwa eksportowa  
// funkcji musi miec postac: initMODULE gdzie 'MODULE' to nazwa glowna
// utworzonego w projekcie modulu binarnego DLL w pliku "MODULE.pyd" 
// nazwa ta moze byc wprost tozsama z identyfikatorem funkcji lub tez
// moze byc skojarzona ze dowolnym identyfikatorem funkcji co mozna 
// wykonac w pliku *.def dolaczonym do projektu o nastepujacej tresci:
//
// EXPORTS
//	initMODULE=_init_
//
extern "C" void _init_(void)
{
	Py_InitModule(PY_MODULE_, _rejestr_); // PY_MODULE_ to makro zawierajace lancuch z p/w nazwe glowna modulu DLL
}

