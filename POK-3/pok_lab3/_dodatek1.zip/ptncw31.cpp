/***********************************************************/
/* Tworzenie Python bindings dla kodu C/C++ w CPython2 API */     
/***********************************************************/

// dodatkowa konfiguracja dla kompilatora MSVC
#pragma warning(disable:4244)
#pragma warning(disable:4996 4005)
#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES
#ifdef UNICODE
# undef UNICODE
# define _MBCS
#endif
#ifndef PY_MODULE_
# define PY_MODULE_ "test"
#endif

// pliki naglowkowe standardu jezyka C/C++ oraz interfejsu API srodowiska Python dla jezyka C/C++:
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iostream>
#include "Python.h"
using namespace std;

// pomocnicza funkcja do porownywania danych:
static int dblcmp(const void *arg1, const void *arg2)
{
 double a = *reinterpret_cast<const double*>(arg1);
 double b = *reinterpret_cast<const double*>(arg2);
 return a<b ? -1 : a>b ? +1 : 0;
}

// podstawowa metoda modulu do sortowania danych:

static PyObject *SortArray(PyObject *self, PyObject *args)
{
 PyObject *list; // krosowanie danych z obiektu krotki Python (argumenty funkcji) do zmiennych typu C/C++
 bool verbose = false;
 if (!PyArg_ParseTuple(args, "O|b", &list, &verbose)) return NULL;

 int n = PyList_Size(list);
 if (verbose)
 cout << "n = " << n << endl;

 double *A = new double[n]; // alokacja pamieci C/C++ (HEAP) dla pomocniczych struktur danych
  
 for (int i=0; i<n; i++) { // dalsze krosowanie danych z obiektu listy Python do struktur typu C/C++
  double x = 0.0;
  PyObject *item = PyList_GetItem(list, i);
  if (PyFloat_Check(item) || PyInt_Check(item)) {
   x = PyFloat_AsDouble(item);
   if (verbose)
   cout << i << ") x = " << x << endl;
  } 
  A[i] = x;
 } 
 
 qsort(A,n,sizeof(double),dblcmp); // wykonanie kodu C/C++ dla algorytmu "Quick Sort" 

 list = PyList_New(n); // alokacja pamieci Python (GC) dla wynikow obliczen  

 for (int i=0; i<n; i++) { // krosowanie wynikow z struktur typu C/C++ do obiektu listy Python
  double y = A[i];
  if (verbose)
  cout << i << ") y = " << y << endl;
  PyObject *item = PyFloat_FromDouble(y);
  PyList_SetItem(list, i, item); 
 } 
 
 delete[] A; // dealokacja pamieci C/C++

 return Py_BuildValue("O", list); // utworzenie obiektu wartosci Python dla rezultatu funkcji
}

// dodatkowa metoda modulu do generowania danych:

static PyObject *RandArray(PyObject *self, PyObject *args)
{
 int n;
 unsigned seed = (int)time(NULL);

 if (!PyArg_ParseTuple(args, "i|I", &n, &seed)) return NULL;

 srand(seed); // wykonanie kodu C/C++ do pseudolosowania danych
 PyObject *list = PyList_New(n);
 for (int i=0; i<n; i++) {
  double y = rand();
  PyObject *item = PyFloat_FromDouble((double)y);
  PyList_SetItem(list, i, item); 
 } 

 return Py_BuildValue("O", list);
}

// rejestrowanie metod modulu i jego zainicjowanie:

static PyMethodDef _rejestr_[] = {
	{"SortArray", SortArray, METH_VARARGS, "Call the 'qsort' C/C++ routine"},
	{"RandArray", RandArray, METH_VARARGS, "Call the 'rand' C/C++ routine"},
	{NULL, NULL}
};

extern "C" void _init_(void)
{
	Py_InitModule(PY_MODULE_, _rejestr_);
}
